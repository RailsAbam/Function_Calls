


Learning = 1
failure = 0
if Learning  > failure:  
    print("Success is Our Goal")
else: 
   if failure < Learning: 
        print("We might have to fail in this Journey")
   else: 
       print("Success Is Ours")
    
    
if Learning > failure and  failure < Learning: 
        print("Success Is Ours!!!")
    




